<template>
    <div style="...">
        Home Components
    </div>
</template>