<template>
    <v-footer
        dark
        padless>
        <v-card
            class="flex green darken-4"
            flat
            tile>
            <v-card-title class="green darken-4">
                <strong class="subheading"> Get connected with us on social networks!</strong>

                <v-spacer></v-spacer>

                <v-btn
                    v-for="icon in icons"
                    :key="icon"
                    class="mx-3"
                    dark
                    icon>
                        <v-icon size="24px">{{ icon }}</v-icon>
                </v-btn>
            </v-card-title>

            <v-card-text class="py-2 white--text text-center">
                © 2018 — <strong> Universitas Riau</strong>
            </v-card-text>
        </v-card>
    </v-footer>
</template>

<script>
    export default {
        data: () => ({
            icons: [
                'mdi-facebook',
                'mdi-twitter',
                'mdi-google-plus',
                'mdi-linkedin',
                'mdi-instagran'
            ]
        })
    }
</script>