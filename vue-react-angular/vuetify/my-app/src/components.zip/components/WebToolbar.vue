<template>
    <v-app>
        <v-toolbar class="flex-grow-0" color="green darken-4" dark>
        <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
        
            <v-btn plain>Home</v-btn>
            <v-btn plain>Profile</v-btn>
            <v-btn plain>Unit/Lembaga</v-btn>
            <v-btn plain>Akademik</v-btn>
            <v-btn plain>Dokumen</v-btn>
            <v-btn plain>Gallery</v-btn>
            <v-btn plain>Peta</v-btn>
            <v-btn plain>Video Profil</v-btn>
            <router-link to='./WebLogin'>
                <v-btn plain class="no-underline" href="/components/WebLogin">Kontak</v-btn>
            </router-link>
        
        <div class="hidden-sm-and-down">
            <v-navigation-drawer
                v-model="drawer"
                absolute
                temporary
                height="800px">
                <v-list class="px-1">
                    <v-list-item-avatar>
                      <v-img src="https://randomuser.me/api/portraits/men/85.jpg"></v-img>
                    </v-list-item-avatar>
                
                    <v-list-item-title>John Leider</v-list-item-title>
                </v-list>
            
                <v-list dense>
                    <v-divider></v-divider>
                
                    <v-list-item
                        v-for="item in items"
                        :key="item.title"
                        link>
                        <v-list-item-icon>
                            <v-icon>{{ item.icon }}</v-icon>
                        </v-list-item-icon>
                    
                        <v-list-item-content>
                            <v-list-item-title>{{ item.title }}</v-list-item-title>
                        </v-list-item-content>
                    </v-list-item>
                </v-list>
            </v-navigation-drawer>
            </div>
        </v-toolbar>
    </v-app>

</template>

<script>
    export default {
        data () {
            return {
                drawer: true,
                items: [
                    { title: 'Home', icon: 'dashboard' },
                    { title: 'About', icon: 'question_answer' }
                ]
            }
        }
    }
</script>
